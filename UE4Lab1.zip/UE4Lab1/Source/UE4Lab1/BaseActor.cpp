// ABaseActor.cpp

#include "BaseActor.h"

// Constructor
ABaseActor::ABaseActor()
{
    // Set this actor to call Tick() every frame
    PrimaryActorTick.bCanEverTick = true;

    // Create the root transform component
    RootTransformComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootTransformComponent"));
    SetRootComponent(RootTransformComponent);

    Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
    Mesh->SetupAttachment(RootTransformComponent);

}

// Called when the game starts or when spawned
void ABaseActor::BeginPlay()
{
    Super::BeginPlay();
}

// Called every frame
void ABaseActor::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}