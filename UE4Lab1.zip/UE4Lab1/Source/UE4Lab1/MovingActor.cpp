// Fill out your copyright notice in the Description page of Project Settings.


#include "MovingActor.h"

AMovingActor::AMovingActor()
{
	PrimaryActorTick.bCanEverTick = true;

}

void AMovingActor::BeginPlay()
{
	Super::BeginPlay();
	MoveToNextPoint();
}

void AMovingActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (!CurrentPoint || (!FirstPoint && !SecondPoint))
		return;
	FVector CurrentLocation = GetActorLocation();
	FVector TargetLocation = CurrentPoint->GetActorLocation();
	FVector Direction = (TargetLocation - CurrentLocation).GetSafeNormal();

	SetActorLocation(CurrentLocation + Direction * 100 * DeltaTime);  // Adjust speed as necessary
	

	if (FVector::Dist(CurrentLocation, TargetLocation) < 100.0f) // Adjust threshold as necessary
	{
		MoveToNextPoint();
	}
}

void AMovingActor::MoveToNextPoint()
{
	// Check if the current point is the first point or if it's null (not set yet)
	if (CurrentPoint == FirstPoint || CurrentPoint == nullptr)
	{
		// If so, switch to the second point
		CurrentPoint = SecondPoint;
	}
	else
	{
		// If the current point is the second point, switch back to the first point
		CurrentPoint = FirstPoint;
	}

	
}

