// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BaseActor.h"
#include "MovingActor.generated.h"

/**
 * 
 */
UCLASS()
class UE4LAB1_API AMovingActor : public ABaseActor
{
	GENERATED_BODY()

public :

	AMovingActor();

	UPROPERTY(EditInstanceOnly, Category = "Movement Point")
	class AActor * FirstPoint;


	UPROPERTY(EditInstanceOnly, Category = "Actor Visual")
	class AActor* SecondPoint;


private:
	class AActor* CurrentPoint;
protected:
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;
private:
	virtual void MoveToNextPoint();

	
};
