// Fill out your copyright notice in the Description page of Project Settings.


#include "OrbitActor.h"

AOrbitActor::AOrbitActor()
{
	PrimaryActorTick.bCanEverTick = true;

}

void AOrbitActor::BeginPlay()
{
	Super::BeginPlay();
	Reset();
}

void AOrbitActor::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    if (!RotateAroundActor) return; // Exit if there's no target actor to rotate around

    // Update the current angle based on rotation speed and delta time
    CurrentAngle += RotationSpeed * DeltaTime;

    // Keep the angle within 0-360 degrees
    if (CurrentAngle >= 360.f) CurrentAngle -= 360.f;
    else if (CurrentAngle < 0.f) CurrentAngle += 360.f;

    // Calculate the new position based on the rotation radius and current angle
    FVector Direction = FVector::ZeroVector;
    if (RotationAxis == FVector::UpVector) // Standard horizontal orbit
    {
        Direction = FVector(FMath::Cos(FMath::DegreesToRadians(CurrentAngle)), FMath::Sin(FMath::DegreesToRadians(CurrentAngle)), 0);
    }
    // Add more conditions if you want to support other axes for orbiting

    FVector NewLocation = RotateAroundActor->GetActorLocation() + Direction * RotationRadius.Size();

    // Set the new location of the actor
    SetActorLocation(NewLocation);

    // Optionally, you can also update the actor's rotation to face the orbit center or any other direction
}

void AOrbitActor::Reset()
{
    CurrentAngle = InitialRotationAngle; // Reset the current angle to the initial value

    // If RotationRadius is set to zero, calculate it based on the current distance from the RotateAroundActor
    if (RotationRadius.IsNearlyZero())
    {
        RotationRadius = GetActorLocation() - RotateAroundActor->GetActorLocation();
    }
}