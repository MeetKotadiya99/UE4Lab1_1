// Copyright Epic Games, Inc. All Rights Reserved.

#include "UE4Lab1.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UE4Lab1, "UE4Lab1" );
