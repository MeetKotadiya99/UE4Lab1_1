// Fill out your copyright notice in the Description page of Project Settings.


#include "MovingActor.h"

AMovingActor::AMovingActor()
{
	PrimaryActorTick.bCanEverTick = true;

}

void AMovingActor::BeginPlay()
{
	Super::BeginPlay();
	MoveToNextPoint();
}
void AMovingActor::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    if (!FirstPoint || !SecondPoint)
    {
        return;
    }

    if (CurrentPoint)
    {
        FVector Delta = CurrentPoint->GetActorLocation() - GetActorLocation();
        float Distance = Delta.Size();

        if (Distance < 100.0f)
        {

            // If the actor is close to the current point, turn 180 degrees and move to the next point
            FRotator NewLookAt = FRotationMatrix::MakeFromX(-Delta.GetSafeNormal()).Rotator();
            SetActorRotation(NewLookAt);
            MoveToNextPoint();
        }
        else
        {


            // If not close, move towards the current point
            FVector Direction = Delta.GetSafeNormal();
            FRotator NewLookAt = FRotationMatrix::MakeFromX(Direction).Rotator();
            NewLookAt.Pitch = 0.0f;
            NewLookAt.Roll = 0.0f;


            FRotator LerpedRotation = FMath::Lerp(GetActorRotation(), NewLookAt, DeltaTime);
            SetActorRotation(LerpedRotation);

            FVector LerpedLocation = FMath::Lerp(GetActorLocation(), CurrentPoint->GetActorLocation(), DeltaTime);
            SetActorLocation(LerpedLocation);
        }
    }
}

void AMovingActor::MoveToNextPoint()
{
	// Check if the current point is the first point or if it's null (not set yet)
	if (CurrentPoint == FirstPoint || CurrentPoint == nullptr)
	{
		// If so, switch to the second point
		CurrentPoint = SecondPoint;
	}
	else
	{
		// If the current point is the second point, switch back to the first point
		CurrentPoint = FirstPoint;
	}

	
}

