// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BaseActor.h"
#include "OrbitActor.generated.h"

/**
 * 
 */
UCLASS()
class UE4LAB1_API AOrbitActor : public ABaseActor
{
	GENERATED_BODY()

public:

	AOrbitActor();

	//target actor to rotate around
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RotateAround")
	class AActor* RotateAroundActor;

	//the speed angles per second in degree
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RotateAround")
	float RotationSpeed = 50.f;

	//The distance to rotate around the actor in CM
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RotateAround")
	FVector RotationRadius = FVector::ZeroVector;
	
	//The 3D Axis around which the object will rotate, default horizontal
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RotateAround")
	FVector RotationAxis = FVector::UpVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RotateAround", meta = (ClampMin = "0.0", ClampMax = "360.0", UlMin = "0.0", UlMax = "360.0"))
	float InitialRotationAngle = 0.f;

protected:
	float CurrentAngle = 0.f;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;


public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

public:
	void Reset();
	
};
